export async function onRequestGet({request,env}) {
 const key=env.API_FOOTBALL_KEY;if(!key)return json({error:"Adaugă API_FOOTBALL_KEY în setările Cloudflare."},503);
 const id=new URL(request.url).searchParams.get("id");if(!id||!/^\d+$/.test(id))return json({error:"ID de meci invalid."},400);
 try{
  const fd=await api(`/fixtures?id=${id}`,key),f=fd.response?.[0];if(!f)return json({error:"Meci negăsit."},404);
  const hid=f.teams.home.id,aid=f.teams.away.id;
  const [hd,ad]=await Promise.all([api(`/fixtures?team=${hid}&last=10`,key),api(`/fixtures?team=${aid}&last=10`,key)]);
  const hm=(hd.response||[]).filter(x=>x.fixture.id!==+id&&x.fixture.status.short==="FT"),am=(ad.response||[]).filter(x=>x.fixture.id!==+id&&x.fixture.status.short==="FT");
  const h=averages(hm,hid),a=averages(am,aid);
  let lh=clamp(h.scored*.58+a.conceded*.42,.2,4),la=clamp(a.scored*.58+h.conceded*.42,.2,4);
  const scale=clamp(2.55/(lh+la),.65,1.3);lh=clamp(lh*scale,.15,4);la=clamp(la*scale,.15,4);
  let scores=[],homeWin=0,draw=0,awayWin=0,over25=0,under25=0;
  for(let x=0;x<=7;x++)for(let y=0;y<=7;y++){const prob=pois(x,lh)*pois(y,la);scores.push({home:x,away:y,prob});if(x>y)homeWin+=prob;else if(x===y)draw+=prob;else awayWin+=prob;if(x+y>=3)over25+=prob;else under25+=prob}
  scores.sort((x,y)=>y.prob-x.prob);
  const htft=["1/1","X/1","2/1","1/X","X/X","2/X","1/2","X/2","2/2"].map(label=>{const [ht,ft]=label.split("/");return {label,prob:outcome(lh*.43,la*.43,ht)*outcome(lh,la,ft)}}).sort((x,y)=>y.prob-x.prob);
  return json({home:{name:f.teams.home.name,games:hm.length},away:{name:f.teams.away.name,games:am.length},predictions:{homeWin,draw,awayWin,over25,under25,expectedHome:lh,expectedAway:la,scores:scores.slice(0,10),htft:htft.slice(0,5)}});
 }catch(e){return json({error:e.message||"Analiza nu a reușit."},502)}
}
async function api(path,key){const r=await fetch("https://v3.football.api-sports.io"+path,{headers:{"x-apisports-key":key}});const d=await r.json();if(!r.ok||(d.errors&&Object.keys(d.errors).length))throw Error("Eroare API. Verifică cheia și limita planului.");return d}
function averages(ms,id){if(!ms.length)return {scored:1.2,conceded:1.2};let s=0,c=0,n=0;for(const m of ms){const home=m.teams.home.id===id;s+=Number(home?m.goals.home:m.goals.away)||0;c+=Number(home?m.goals.away:m.goals.home)||0;n++}return {scored:s/n,conceded:c/n}}
function pois(k,l){let p=Math.exp(-l);for(let i=1;i<=k;i++)p*=l/i;return p}
function clamp(v,a,b){return Math.max(a,Math.min(b,v))}
function outcome(lh,la,label){let h=0,d=0,a=0;for(let x=0;x<=7;x++)for(let y=0;y<=7;y++){let p=pois(x,lh)*pois(y,la);if(x>y)h+=p;else if(x===y)d+=p;else a+=p}return label==="1"?h:label==="X"?d:a}
function json(d,status=200){return new Response(JSON.stringify(d),{status,headers:{"content-type":"application/json; charset=utf-8","cache-control":"public, max-age=30"}})}