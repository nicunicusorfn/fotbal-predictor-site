export async function onRequestGet({request,env}) {
 const key=env.API_FOOTBALL_KEY;
 if(!key)return json({error:"API-ul nu este configurat. Adaugă API_FOOTBALL_KEY în Cloudflare."},503);
 const date=new URL(request.url).searchParams.get("date");
 if(!date||!/^\d{4}-\d{2}-\d{2}$/.test(date))return json({error:"Data trebuie să fie AAAA-LL-ZZ."},400);
 const r=await fetch("https://v3.football.api-sports.io/fixtures?date="+encodeURIComponent(date),{headers:{"x-apisports-key":key}});
 const d=await r.json();if(!r.ok||(d.errors&&Object.keys(d.errors).length))return json({error:"API-Football a returnat o eroare. Verifică cheia și limita planului."},502);
 return json({response:d.response||[],results:d.results||0});
}
function json(d,status=200){return new Response(JSON.stringify(d),{status,headers:{"content-type":"application/json; charset=utf-8","cache-control":"public, max-age=60"}})}